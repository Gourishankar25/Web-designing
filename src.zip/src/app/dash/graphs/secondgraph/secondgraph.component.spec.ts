import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SecondgraphComponent } from './secondgraph.component';

describe('SecondgraphComponent', () => {
  let component: SecondgraphComponent;
  let fixture: ComponentFixture<SecondgraphComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SecondgraphComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SecondgraphComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
