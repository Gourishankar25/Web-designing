import { Component, OnInit } from '@angular/core';
import { Chart} from 'chart.js';
@Component({
  selector: 'app-thirdgraph',
  templateUrl: './thirdgraph.component.html',
  styleUrls: ['./thirdgraph.component.css']
})
export class ThirdgraphComponent implements OnInit {
  LineChart=[];
  PieChart=[];
  BarChart=[];
  labeldata=["Jan", "Feb", "March", "April", "May", "June","July","Aug","Sep","Oct","Nov","Dec"];
  datadata=[1,2,3,4,5,6,7,8,9,10,11,12];
  
  changeidp()
  {
    this.PieChart = new Chart('pieChart', {
      type: 'pie',
    data: {
      labels: this.labeldata,
     datasets: [{
         label: 'Device vs Time',
         data: this.datadata,
         backgroundColor: [
             'rgba(255, 99, 132, 0.2)',
             'rgba(54, 162, 235, 0.2)',
             'rgba(255, 206, 86, 0.2)',
             'rgba(75, 192, 192, 0.2)',
             'rgba(153, 102, 255, 0.2)',
             'rgba(255, 159, 64, 0.2)',
             'rgba(255, 99, 120, 0.2)',
             'rgba(54, 162, 235, 0.2)',
             'rgba(255, 206, 95, 0.2)',
             'rgba(75, 192, 150, 0.2)',
             'rgba(153, 102, 265, 0.2)',
             'rgba(255, 159, 75, 0.2)'
         ],
         borderColor: [
             'rgba(255,99,132,1)',
             'rgba(54, 162, 235, 1)',
             'rgba(255, 206, 86, 1)',
             'rgba(75, 192, 192, 1)',
             'rgba(153, 102, 255, 1)',
             'rgba(255, 159, 64, 1)',
             'rgba(255, 99, 120, 1)',
             'rgba(54, 162, 235, 1)',
             'rgba(255, 206, 95, 1)',
             'rgba(75, 192, 150, 1)',
             'rgba(153, 102, 265, 1)',
             'rgba(255, 159, 75, 1)'
         ],
         borderWidth: 1
     }]
    }, 
    options: {
     title:{
         text:"Pie Chart",
         display:true
     },
     scales: {
         yAxes: [{
             ticks: {
                 beginAtZero:true
             }
         }]
     }
    }
    });
  }
  changeidb()
  {
    this.BarChart = new Chart('pieChart', {
      type: 'bar',
    data: {
      labels: this.labeldata,
     datasets: [{
         label: 'Device vs Time',
         data: this.datadata,
         backgroundColor: [
             'rgba(255, 99, 132, 0.2)',
             'rgba(54, 162, 235, 0.2)',
             'rgba(255, 206, 86, 0.2)',
             'rgba(75, 192, 192, 0.2)',
             'rgba(153, 102, 255, 0.2)',
             'rgba(255, 159, 64, 0.2)',
             'rgba(255, 99, 120, 0.2)',
             'rgba(54, 162, 235, 0.2)',
             'rgba(255, 206, 95, 0.2)',
             'rgba(75, 192, 150, 0.2)',
             'rgba(153, 102, 265, 0.2)',
             'rgba(255, 159, 75, 0.2)'
         ],
         borderColor: [
             'rgba(255,99,132,1)',
             'rgba(54, 162, 235, 1)',
             'rgba(255, 206, 86, 1)',
             'rgba(75, 192, 192, 1)',
             'rgba(153, 102, 255, 1)',
             'rgba(255, 159, 64, 1)',
             'rgba(255, 99, 120, 1)',
             'rgba(54, 162, 235, 1)',
             'rgba(255, 206, 95, 1)',
             'rgba(75, 192, 150, 1)',
             'rgba(153, 102, 265, 1)',
             'rgba(255, 159, 75, 1)'
         ],
         borderWidth: 1
     }]
    }, 
    options: {
     title:{
         text:"Bar Chart",
         display:true
     },
     scales: {
         yAxes: [{
             ticks: {
                 beginAtZero:true
             }
         }]
     }
    }
    });
  }
  changeidl(){
    this.LineChart = new Chart('pieChart', {
      type: 'line',
    data: {
     labels: this.labeldata,
     datasets: [{
         label: 'Device vs Time',
         data: this.datadata,
         fill:false,
         lineTension:0.2,
         borderColor:"red",
         borderWidth: 1
     }]
    }, 
    options: {
     title:{
         text:"Line Chart",
         display:true
     },
     scales: {
         yAxes: [{
             ticks: {
                 beginAtZero:true
             }
         }]
     }
    }
    });
  }
  constructor() { }

  ngOnInit() {
    
     this.changeidp();
    
  }

}