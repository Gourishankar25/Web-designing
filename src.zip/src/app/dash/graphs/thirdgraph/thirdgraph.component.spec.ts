import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ThirdgraphComponent } from './thirdgraph.component';

describe('ThirdgraphComponent', () => {
  let component: ThirdgraphComponent;
  let fixture: ComponentFixture<ThirdgraphComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ThirdgraphComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ThirdgraphComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
