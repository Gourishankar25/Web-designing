import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FourthgraphComponent } from './fourthgraph.component';

describe('FourthgraphComponent', () => {
  let component: FourthgraphComponent;
  let fixture: ComponentFixture<FourthgraphComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FourthgraphComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FourthgraphComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
