import { Component, OnInit } from '@angular/core';
import {Chart} from 'chart.js';
@Component({
  selector: 'app-fourthgraph',
  templateUrl: './fourthgraph.component.html',
  styleUrls: ['./fourthgraph.component.css']
})
export class FourthgraphComponent implements OnInit {
  LineChart=[];
  PieChart=[];
  BarChart=[];
  LChart=[];
  labeldata=["Jan", "Feb", "March", "April", "May", "June","July","Aug","Sep","Oct","Nov","Dec"];
  datadata=[12,7,15,5,25,10,11,16,9,3,1,19];
  
  changeidp()
  {
    this.PieChart = new Chart('lChart', {
      type: 'pie',
    data: {
      labels: this.labeldata,
     datasets: [{
         label: 'Load vs Time(months)',
         data: this.datadata,
         backgroundColor: [
             'rgba(255, 99, 132, 0.2)',
             'rgba(54, 162, 235, 0.2)',
             'rgba(255, 206, 86, 0.2)',
             'rgba(75, 192, 192, 0.2)',
             'rgba(153, 102, 255, 0.2)',
             'rgba(255, 159, 64, 0.2)',
             'rgba(255, 99, 120, 0.2)',
             'rgba(54, 162, 235, 0.2)',
             'rgba(255, 206, 95, 0.2)',
             'rgba(75, 192, 150, 0.2)',
             'rgba(153, 102, 265, 0.2)',
             'rgba(255, 159, 75, 0.2)'
         ],
         borderColor: [
             'rgba(255,99,132,1)',
             'rgba(54, 162, 235, 1)',
             'rgba(255, 206, 86, 1)',
             'rgba(75, 192, 192, 1)',
             'rgba(153, 102, 255, 1)',
             'rgba(255, 159, 64, 1)',
             'rgba(255, 99, 120, 1)',
             'rgba(54, 162, 235, 1)',
             'rgba(255, 206, 95, 1)',
             'rgba(75, 192, 150, 1)',
             'rgba(153, 102, 265, 1)',
             'rgba(255, 159, 75, 1)'
         ],
         borderWidth: 1
     }]
    }, 
    options: {
     title:{
         text:"Pie Chart",
         display:true
     },
     scales: {
         yAxes: [{
             ticks: {
                 beginAtZero:true
             }
         }]
     }
    }
    });
  }
  changeidb()
  {
    this.BarChart = new Chart('lChart', {
      type: 'bar',
    data: {
      labels: this.labeldata,
     datasets: [{
         label: 'Load vs Time(months)',
         data: this.datadata,
         backgroundColor: [
             'rgba(255, 99, 132, 0.2)',
             'rgba(54, 162, 235, 0.2)',
             'rgba(255, 206, 86, 0.2)',
             'rgba(75, 192, 192, 0.2)',
             'rgba(153, 102, 255, 0.2)',
             'rgba(255, 159, 64, 0.2)',
             'rgba(255, 99, 120, 0.2)',
             'rgba(54, 162, 235, 0.2)',
             'rgba(255, 206, 95, 0.2)',
             'rgba(75, 192, 150, 0.2)',
             'rgba(153, 102, 265, 0.2)',
             'rgba(255, 159, 75, 0.2)'
         ],
         borderColor: [
             'rgba(255,99,132,1)',
             'rgba(54, 162, 235, 1)',
             'rgba(255, 206, 86, 1)',
             'rgba(75, 192, 192, 1)',
             'rgba(153, 102, 255, 1)',
             'rgba(255, 159, 64, 1)',
             'rgba(255, 99, 120, 1)',
             'rgba(54, 162, 235, 1)',
             'rgba(255, 206, 95, 1)',
             'rgba(75, 192, 150, 1)',
             'rgba(153, 102, 265, 1)',
             'rgba(255, 159, 75, 1)'
         ],
         borderWidth: 1
     }]
    }, 
    options: {
     title:{
         text:"Bar Chart",
         display:true
     },
     scales: {
         yAxes: [{
             ticks: {
                 beginAtZero:true
             }
         }]
     }
    }
    });
  }
  changeidl(){
    this.LineChart = new Chart('lChart', {
      type: 'line',
    data: {
     labels: this.labeldata,
     datasets: [{
         label: 'Load vs Time(months)',
         data: this.datadata,
         fill:false,
         lineTension:0.2,
         borderColor:"red",
         borderWidth: 1
     }]
    }, 
    options: {
     title:{
         text:"Line Chart",
         display:true
     },
     scales: {
         yAxes: [{
             ticks: {
                 beginAtZero:true
             }
         }]
     }
    }
    });
  }
  constructor() { }

  ngOnInit() {
    this.changeidl();
  }

}