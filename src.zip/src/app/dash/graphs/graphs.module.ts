import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FirstgraphComponent } from './firstgraph/firstgraph.component';
import { SecondgraphComponent } from './secondgraph/secondgraph.component';
import { ThirdgraphComponent } from './thirdgraph/thirdgraph.component';
import { FourthgraphComponent } from './fourthgraph/fourthgraph.component';

@NgModule({
  declarations: [FirstgraphComponent, SecondgraphComponent, ThirdgraphComponent, FourthgraphComponent],
  exports: [
    FirstgraphComponent,
    SecondgraphComponent,
    ThirdgraphComponent,
    FourthgraphComponent
  ],
  imports: [
    CommonModule
  ]
})
export class GraphsModule { }
