import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FirstgraphComponent } from './firstgraph.component';

describe('FirstgraphComponent', () => {
  let component: FirstgraphComponent;
  let fixture: ComponentFixture<FirstgraphComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FirstgraphComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FirstgraphComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
