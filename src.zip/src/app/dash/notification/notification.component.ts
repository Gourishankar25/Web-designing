import { Component, OnInit } from '@angular/core';
import { ChangeDetectionStrategy } from '@angular/core';
@Component({
  selector: 'app-notification',
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class NotificationComponent implements OnInit {
  //items = Array.from({length: 100000}).map((_, i) => `Item #${i}`);
  items = ['Water Motor is still Running!','Refrigerator is off!','Water Motor is still Running!','Refrigerator is off!','Water Motor is still Running!','Refrigerator is off!','Water Motor is still Running!','Refrigerator is off!','Water Motor is still Running!','Refrigerator is off!']
  constructor() { }

  ngOnInit() {
  }

}
