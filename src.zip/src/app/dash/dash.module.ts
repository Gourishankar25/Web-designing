import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LocationComponent } from './location/location.component';
import { NotificationComponent } from './notification/notification.component';
import { GraphsModule } from './graphs/graphs.module';
import { PanelModule } from './panel/panel.module';
import {ScrollDispatchModule} from '@angular/cdk/scrolling';
import {MatMenuModule} from '@angular/material/menu';
import {MatButtonModule} from '@angular/material/button';
import {MatIconModule} from '@angular/material/icon';
@NgModule({
  declarations: [LocationComponent, NotificationComponent],
  imports: [
    CommonModule,
    GraphsModule,
    PanelModule,
    ScrollDispatchModule,
    MatButtonModule,
    MatIconModule,
    MatMenuModule
  ],
  exports: [
    LocationComponent,
    NotificationComponent,
    PanelModule,
    GraphsModule,
    ScrollDispatchModule
  ]
})
export class DashModule { }
