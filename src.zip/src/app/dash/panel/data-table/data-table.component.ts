import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatTable } from '@angular/material';
import { DataTableDataSource, DataTableItem } from './data-table-datasource';

@Component({
  selector: 'app-data-table',
  templateUrl: './data-table.component.html',
  styleUrls: ['./data-table.component.css']
})
export class DataTableComponent implements AfterViewInit, OnInit {
  @ViewChild(MatPaginator, {static: false}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: false}) sort: MatSort;
  @ViewChild(MatTable, {static: false}) table: MatTable<DataTableItem>;
  dataSource: DataTableDataSource;

  /** Columns displayed in the table. Columns IDs can be added, removed, or reordered. */
  displayedColumns = ['name', 'purl','location'];
  
  list=[];
  addtotab(obj ){

    
    if(obj.status=="off")
    {
      obj.status="on";
      obj.prestate="off";
    }
    else
    {
      obj.status="off";
      obj.prestate="on";
    }
    if(this.list.lastIndexOf(obj)==-1)
    {
      this.list.push(obj);
      console.log("no obj so pushed");
    }
    else
    {
      const index = this.list.indexOf(obj, 0);
      this.list.splice(index, 1);
      console.log("element removed");
    }
    
   console.log(this.list);
  }
  ngOnInit() {
    this.dataSource = new DataTableDataSource();
  }

  ngAfterViewInit() {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
    this.table.dataSource = this.dataSource;
  }
}
